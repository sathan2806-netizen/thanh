# Auto App Manager – dự án Android Kotlin

## Tính năng
- Liệt kê các ứng dụng có biểu tượng khởi chạy trên điện thoại (không phải tất cả gói hệ thống).
- Tìm kiếm theo tên hoặc package; đánh dấu yêu thích và lọc yêu thích; quét lại khi quay về ứng dụng.
- Mở ứng dụng được chọn trên **điện thoại**.
- Không cần quyền truy cập vị trí, danh bạ hay tin nhắn.

## Giới hạn Android Auto
Android Auto không hỗ trợ ứng dụng launcher tổng quát để đưa mọi ứng dụng điện thoại lên màn hình xe. Dự án không cung cấp giao diện CarAppService vì danh mục quản lý ứng dụng không thuộc loại được hỗ trợ. Không thể mở Zalo, YouTube hay ứng dụng bất kỳ trên màn hình ô tô thông qua API Android Auto công khai. Người dùng kiểm tra các ứng dụng tương thích tại Android Auto > Customize launcher trong cài đặt điện thoại.

## Biên dịch APK
1. Cài Android Studio và Android SDK Platform 35, Build Tools phù hợp, JDK 17.
2. Mở thư mục dự án này trong Android Studio, đợi Gradle Sync (cần mạng lần đầu).
3. Chọn Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK debug nằm tại `app/build/outputs/apk/debug/app-debug.apk`.

Dự án chưa được biên dịch hoặc thử nghiệm trên thiết bị thật trong môi trường hiện tại.


## Verification (2026-10-25)
Source reviewed; **APK not built** in this environment because Android SDK, Gradle, and network/DNS access are unavailable.
This is a PHONE application; it does NOT register an Android Auto car app or show a launcher on the car display. Android Auto app visibility and launch are controlled by Android Auto.
Build using Android Studio with Android SDK 35 and Gradle plugin 8.7.3 / Kotlin 2.0.21. Open the project folder and run Build > Build APK(s).
