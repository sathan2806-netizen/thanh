package com.example.autoappmanager

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.widget.*

class MainActivity : Activity() {
    private lateinit var container: LinearLayout
    private lateinit var search: EditText
    private lateinit var status: TextView
    private var apps: List<AppEntry> = emptyList()
    private var onlyFavorites = false
    private val prefs by lazy { getSharedPreferences("favorites", MODE_PRIVATE) }
    private data class AppEntry(val label: String, val packageName: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 12) }
        val title = TextView(this).apply { text = "Auto App Manager"; textSize = 24f; setTypeface(null, Typeface.BOLD) }
        root.addView(title)
        root.addView(TextView(this).apply {
            text = "Danh sách ứng dụng trên điện thoại. Android Auto chỉ hiển thị ứng dụng được hệ thống hỗ trợ; ứng dụng này không mở ứng dụng tùy ý trên màn hình xe."
            setPadding(0, 12, 0, 12)
        })
        search = EditText(this).apply { hint = "Tìm ứng dụng"; setSingleLine(true) }
        root.addView(search)
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val refresh = Button(this).apply { text = "Quét lại"; setOnClickListener { loadApps() } }
        val favorites = Button(this).apply { text = "Yêu thích"; setOnClickListener { onlyFavorites = !onlyFavorites; text = if (onlyFavorites) "Tất cả" else "Yêu thích"; render() } }
        controls.addView(refresh); controls.addView(favorites)
        root.addView(controls)
        status = TextView(this)
        root.addView(status)
        val scroll = ScrollView(this)
        container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(container)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { render() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        loadApps()
    }

    override fun onResume() {
        super.onResume()
        if (::container.isInitialized && ::search.isInitialized) loadApps()
    }

    private fun loadApps() {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val results = if (android.os.Build.VERSION.SDK_INT >= 33) {
            packageManager.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            packageManager.queryIntentActivities(intent, 0)
        }
        apps = results.map { AppEntry(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
        render()
    }

    private fun render() {
        container.removeAllViews()
        val query = search.text.toString().trim()
        val visible = apps.filter { it.label.contains(query, true) || it.packageName.contains(query, true) }
            .filter { !onlyFavorites || prefs.getBoolean(it.packageName, false) }
        status.text = "${visible.size} ứng dụng có thể khởi chạy (không phải danh sách tương thích Android Auto)"
        if (visible.isEmpty()) container.addView(TextView(this).apply { text = "Không tìm thấy ứng dụng phù hợp"; setPadding(12, 24, 12, 24) })
        visible.forEach { app ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL }
            val icon = ImageView(this).apply {
                try { setImageDrawable(packageManager.getApplicationIcon(app.packageName)) } catch (_: PackageManager.NameNotFoundException) {}
            }
            row.addView(icon, LinearLayout.LayoutParams(56, 56))
            val name = TextView(this).apply { text = app.label; setPadding(12, 0, 8, 0) }
            row.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
            val star = CheckBox(this).apply {
                isChecked = prefs.getBoolean(app.packageName, false)
                contentDescription = "Yêu thích ${app.label}"
                setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(app.packageName, checked).apply(); if (onlyFavorites && !checked) render() }
            }
            row.addView(star)
            val open = Button(this).apply {
                text = "Mở"
                setOnClickListener {
                    val launch = packageManager.getLaunchIntentForPackage(app.packageName)
                    if (launch != null) try { startActivity(launch) } catch (_: Exception) { Toast.makeText(this@MainActivity, "Không mở được ứng dụng", Toast.LENGTH_SHORT).show() }
                }
            }
            row.addView(open)
            container.addView(row)
        }
    }
}
